# SkyPlan

A weather planner that answers the questions people actually ask each morning: do I need an umbrella, sunscreen, can I hang the washing out, and is today good for outdoor plans?

**Live demo:** https://ThoeMthembu.github.io/skyplan (after you enable GitHub Pages)

## The problem it solves
Weather apps show numbers and icons. SkyPlan turns the forecast into clear daily advice, which is useful in places with sudden afternoon storms and strong UV, such as the South African Highveld.

## Features
- Search any city worldwide, with a choice list when names match several places
- Plain-language advice for umbrella, sun protection, washing and outdoor plans
- 5-day forecast with rain chance and temperature range
- Quick picks for major South African cities, plus your recent searches (saved in the browser)
- Loading, empty, error and offline states with clear messages
- Cancels outdated requests so quick searches never show stale results
- Responsive, keyboard friendly, light and dark mode

## Tech
HTML, CSS and vanilla JavaScript (`fetch`, `async/await`, `AbortController`). Data from the free [Open-Meteo](https://open-meteo.com/) geocoding and forecast APIs. No API key and no build step.

## Run locally
Open `index.html` in a browser, or serve the folder with any static server.

## Deploy on GitHub Pages
Create a repo named `skyplan`, upload `index.html` and this README, then go to Settings, Pages, choose the `main` branch and the root folder, and save.

## What I would add next
Hourly forecast, °C/°F toggle, tests for the advice rules, and a "use my location" button.

## What I learned
Working with two REST APIs, handling async errors and cancellation, and turning raw data into helpful decisions for users.
