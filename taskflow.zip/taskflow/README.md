# TaskFlow

A full-stack task manager where each person signs up, logs in and manages their own private tasks.

## Features
- Account sign-up and login with hashed passwords (bcrypt)
- Sessions via signed JWT in an httpOnly, SameSite=Strict cookie
- Full CRUD on tasks: create, read, update (title and status), delete
- Every task query is scoped to the logged-in user, so nobody can see or change another person's tasks
- Server-side validation and clear error messages
- Responsive, keyboard-friendly, light and dark mode

## Tech stack
Node.js, Express, SQLite (better-sqlite3), bcryptjs, jsonwebtoken, vanilla JavaScript front end.

## Run locally
```bash
npm install
npm start
```
Open http://localhost:3000.

Optional environment variables: `PORT`, `JWT_SECRET` (required when `NODE_ENV=production`), `DB_FILE`.

## API
| Method | Route | Description |
|---|---|---|
| POST | /api/auth/register | Create an account |
| POST | /api/auth/login | Log in |
| POST | /api/auth/logout | Log out |
| GET | /api/auth/me | Current user |
| GET | /api/tasks | List my tasks |
| POST | /api/tasks | Create a task |
| PUT | /api/tasks/:id | Update title, notes or status |
| DELETE | /api/tasks/:id | Delete a task |

## Deploy
Works on Render or Railway: build command `npm install`, start command `npm start`, and set `JWT_SECRET` and `NODE_ENV=production`. Note that these hosts need a persistent disk for the SQLite file (or switch to PostgreSQL).

## What I would add next
Automated API tests, rate limiting on the login route, drag-and-drop boards, and a PostgreSQL option.

## What I learned
Designing a REST API, password hashing, cookie-based sessions, and scoping every query by user to keep data private.
