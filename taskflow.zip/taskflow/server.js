const express = require('express');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');

const PROD = process.env.NODE_ENV === 'production';
const SECRET = process.env.JWT_SECRET || 'dev-only-secret-change-me';
if (PROD && !process.env.JWT_SECRET) { console.error('JWT_SECRET must be set in production.'); process.exit(1); }

// ---- Database ----
const db = new Database(process.env.DB_FILE || path.join(__dirname, 'data.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    notes TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'todo' CHECK (status IN ('todo','doing','done')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);

// ---- App setup ----
const app = express();
app.use(express.json({ limit: '10kb' }));
app.use(express.static(path.join(__dirname, 'public')));

const STATUSES = ['todo', 'doing', 'done'];
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const str = (v) => (typeof v === 'string' ? v.trim() : '');

function issueCookie(res, userId) {
  const token = jwt.sign({ id: userId }, SECRET, { expiresIn: '7d' });
  res.cookie('token', token, { httpOnly: true, sameSite: 'strict', secure: PROD, maxAge: 7 * 24 * 3600 * 1000 });
}

function requireAuth(req, res, next) {
  const raw = (req.headers.cookie || '').split(';').map((c) => c.trim()).find((c) => c.startsWith('token='));
  if (!raw) return res.status(401).json({ error: 'Please log in.' });
  try {
    req.userId = jwt.verify(decodeURIComponent(raw.slice(6)), SECRET).id;
    next();
  } catch {
    res.status(401).json({ error: 'Your session expired. Please log in again.' });
  }
}

// ---- Auth routes ----
app.post('/api/auth/register', (req, res) => {
  const name = str(req.body.name), email = str(req.body.email).toLowerCase(), password = req.body.password;
  if (!name || name.length > 60) return res.status(400).json({ error: 'Enter your name (up to 60 characters).' });
  if (!EMAIL_RE.test(email)) return res.status(400).json({ error: 'Enter a valid email address.' });
  if (typeof password !== 'string' || password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters.' });
  if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email)) return res.status(409).json({ error: 'That email is already registered. Try logging in.' });
  const hash = bcrypt.hashSync(password, 12);
  const info = db.prepare('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)').run(name, email, hash);
  issueCookie(res, info.lastInsertRowid);
  res.status(201).json({ id: info.lastInsertRowid, name, email });
});

app.post('/api/auth/login', (req, res) => {
  const email = str(req.body.email).toLowerCase(), password = req.body.password;
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user || typeof password !== 'string' || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'Email or password is incorrect.' });
  }
  issueCookie(res, user.id);
  res.json({ id: user.id, name: user.name, email: user.email });
});

app.post('/api/auth/logout', (req, res) => {
  res.clearCookie('token');
  res.json({ ok: true });
});

app.get('/api/auth/me', requireAuth, (req, res) => {
  const user = db.prepare('SELECT id, name, email FROM users WHERE id = ?').get(req.userId);
  if (!user) return res.status(401).json({ error: 'Please log in.' });
  res.json(user);
});

// ---- Task routes (CRUD, scoped to the logged-in user) ----
function validateTask(body, partial) {
  const out = {};
  if (!partial || body.title !== undefined) {
    out.title = str(body.title);
    if (!out.title || out.title.length > 120) return { error: 'Title is required (up to 120 characters).' };
  }
  if (body.notes !== undefined) {
    out.notes = str(body.notes);
    if (out.notes.length > 1000) return { error: 'Notes can be up to 1000 characters.' };
  }
  if (body.status !== undefined) {
    if (!STATUSES.includes(body.status)) return { error: 'Status must be todo, doing or done.' };
    out.status = body.status;
  }
  return { value: out };
}

app.get('/api/tasks', requireAuth, (req, res) => {
  res.json(db.prepare('SELECT id, title, notes, status, created_at FROM tasks WHERE user_id = ? ORDER BY id DESC').all(req.userId));
});

app.post('/api/tasks', requireAuth, (req, res) => {
  const { error, value } = validateTask(req.body, false);
  if (error) return res.status(400).json({ error });
  const info = db.prepare('INSERT INTO tasks (user_id, title, notes, status) VALUES (?, ?, ?, ?)')
    .run(req.userId, value.title, value.notes || '', value.status || 'todo');
  res.status(201).json(db.prepare('SELECT id, title, notes, status, created_at FROM tasks WHERE id = ?').get(info.lastInsertRowid));
});

app.put('/api/tasks/:id', requireAuth, (req, res) => {
  const { error, value } = validateTask(req.body, true);
  if (error) return res.status(400).json({ error });
  const current = db.prepare('SELECT * FROM tasks WHERE id = ? AND user_id = ?').get(req.params.id, req.userId);
  if (!current) return res.status(404).json({ error: 'Task not found.' });
  const next = { ...current, ...value };
  db.prepare('UPDATE tasks SET title = ?, notes = ?, status = ? WHERE id = ?').run(next.title, next.notes, next.status, current.id);
  res.json({ id: current.id, title: next.title, notes: next.notes, status: next.status, created_at: current.created_at });
});

app.delete('/api/tasks/:id', requireAuth, (req, res) => {
  const info = db.prepare('DELETE FROM tasks WHERE id = ? AND user_id = ?').run(req.params.id, req.userId);
  if (!info.changes) return res.status(404).json({ error: 'Task not found.' });
  res.status(204).end();
});

app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid JSON.' });
  console.error(err);
  res.status(500).json({ error: 'Something went wrong on our side.' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`TaskFlow running on http://localhost:${PORT}`));
